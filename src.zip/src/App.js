import logo from './logo.svg';
//import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Fact from './Fact';
import Hello from './Hello'
import Marksheet from './Marksheet';
import { Layout } from './Layout';
import CheckboxExample from './CheckboxExample'
import DropdownListExample from './DropdownListExample'
import Checkprime from './Checkprime'
import { LayoutAdmin } from './LayoutAdmin';
import FetchAPIGETExample from './FetchAPIGETExample';
import { RestAPIPostExample } from './RestAPIPostExample';
import  RestAPIPutExample  from './RestAPIPutExample';
import RestAPIDeleteExample from './RestAPIDeleteExample';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Layout />} > 
      <Route  index element={<FetchAPIGETExample />} /> 
      <Route path="/fetchapi" element={<FetchAPIGETExample />} /> 
      <Route path="/postapi" element={<RestAPIPostExample />} /> 
      <Route path="/putapi" element={<RestAPIPutExample />} /> 
      <Route path="/deleteapi" element={<RestAPIDeleteExample />} /> 
      </Route>
      
    </Routes>
    <Routes>
    <Route path="/admin" element={<LayoutAdmin />} > 
      <Route  index element={<Checkprime />} /> 
      <Route  path="/admin/checkprime" element={<Checkprime />} /> 
      <Route path="/admin/checkbox" element={<CheckboxExample />} /> 
      <Route path="/admin/dropdown" element={<DropdownListExample />} /> 
      </Route>
    </Routes>
    </BrowserRouter>
  );
}

export default App;
