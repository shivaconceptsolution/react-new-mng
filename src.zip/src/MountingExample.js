import React from "react";
export default class MountingExample extends React.Component
{
     constructor(props)
     {
        super(props);
        this.state= {a:10};
     }
     componentDidMount()
     {
        setTimeout(()=>{this.setState({a:20})},1000);
     }
     render()
     {
        return(<div>
                {this.state.a}
        </div>)
     }
}