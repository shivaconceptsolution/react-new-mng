import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router";
const RestAPIDeleteExample =()=>
{
    
        let data = useLocation().state;
        const[post, setPost] = React.useState('');
        const tid = useRef();
        const tname = useRef();
      //  const temail = useRef();
     //   const tadd = useRef();
    
       
     useEffect(() => {
            fetch("http://127.0.0.1:5000/studata/"+data)
            .then(response => response.json())
            .then(data => {setPost(data);console.log(post);} )
          },[]);
    
  
   var submitdata= (e)=>{
    
   
   
    fetch('http://127.0.0.1:5000/studata/'+data,{
            method: 'Delete'}
           ).then(res => res.json()).then((data) => {}).catch(console.log('error'))
       window.location.href='/fetchapi';
    }
  

    return(<div>
         <h1>Delete RECORD EXAMPLE</h1>
        <div>{post.rno}</div> 
        <div>{post.name}</div> 
       
        <br/>
        <input type="button" value="delete" onClick={submitdata} />
        
    </div>)
}
export default RestAPIDeleteExample;