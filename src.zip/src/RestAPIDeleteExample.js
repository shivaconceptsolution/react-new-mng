import React from "react";
export default class RestAPIDeleteExample extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {tdata:'',tid:''}
    }
    enterData=(e)=>{
       
           this.setState({'tid':e.target.value});
      
    }
  
   submitdata=()=>{
    fetch('http://127.0.0.1:3001/posts/'+this.state.tid,{
        method: 'DELETE'
         });
   }
    render(){
        return(<div>
             <h1>Delete RECORD EXAMPLE</h1>
        <input type="text" onChange={this.enterData}  placeholder="Enter id" id="tid" /> <br/>
      
        <br/>
        <input type="button" value="Insert" onClick={this.submitdata} />
            <h1>Delete Success</h1>
        </div>)
    }
}