import React from "react"
export default class HelloClass extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state= {message:"Hello World"}
    }
    changeMessage=()=>
    {
         this.setState({message:"Welcome in CLASS COMPONENT"})
    }
    render()
    {
        return(<div>
            <input type="button" value="Click" onClick={this.changeMessage} />
            <br/>
            {this.state.message}
        </div>)
    }

}