import { useRef, useState } from "react"

const UncontrollerprimeExample=()=>{
    const num = useRef()
    const [res,setRes] = useState(undefined)
    const checkprime=()=>{
        var a = parseInt(num.current.value);
        var result = "prime";
        if(a>2 && a%2==0 || a<2)
        {
            result = "not prime";
        }
        else
        {
            for(var i=2;i<a;i++)
            {
                if(a%i==0)
                {
                    result = "not prime";
                    break;
                }
            }
        }
       setRes(result)

    }
    return(<div>
           <input type="text" placeholder="Enter Number" ref={num} />
           <br/>
           <input type="button"  value="click" onClick={checkprime} />
           {res}
    </div>)
}

export default UncontrollerprimeExample;