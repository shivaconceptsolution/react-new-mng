import { Link } from 'react-router-dom';
import './App.css';
function HeaderAdmin()
{
    return(<header>
       <h3>Welcome in Admin Header Component</h3>
       <Link to="/admin/dropdown">First Admin</Link>
       <Link to="/admin/checkbox">Second Admin </Link>
       <Link to="/admin/checkprime">Third Admin</Link>
      </header>)
}

export default HeaderAdmin;