import React from "react"
import { Outlet } from "react-router-dom";
import Footer from "./Footer";
import HeaderAdmin from "./HeaderAdmin";
export class LayoutAdmin extends React.Component
{
    
    render(){
        return(
          <div>
             <HeaderAdmin />
              <section>
              <Outlet />     
              </section>
              <Footer/>
             
          </div>

        );

    }

}
