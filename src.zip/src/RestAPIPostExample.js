import React from "react";
export class RestAPIPostExample extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {tid:'',tname:''}
    }
    enterData=(e)=>{
        if(e.target.id=='tid')
        {
           this.setState({'tid':e.target.value});
        }
        else if(e.target.id=='tname')
        {
            this.setState({'tname':e.target.value});
        }
      /*  else if(e.target.id=='temail')
        {
            this.setState({'temail':e.target.value});
        }
        else
        {
            this.setState({'taddress':e.target.value});
        }*/
    }
    submitdata=()=>{
        fetch('http://127.0.0.1:5000/studata',{
            method: 'POST',
            body: JSON.stringify({
             rno:parseInt(this.state.tid),
             name:this.state.tname,
           //  email:this.state.temail,
           //  adderss:this.state.taddress
         }),
            headers:{"content-type":"application/json; charset=UTF-8"}  
             }).then(res => res.json())
   
       .then((data) => {
   
          console.log(data)
          this.setState({tdata:data})
   
       }).catch(console.log)
    }
    

render(){
    return(<div>
        <h1>INSERT RECORD EXAMPLE</h1>
        <input type="text" onChange={this.enterData}  placeholder="Enter id" id="tid" /> <br/>
        <input type="text" onChange={this.enterData}  placeholder="Enter name" id="tname" /> <br/>
       
        <br/>
        <input type="button" value="Insert" onClick={this.submitdata} />
      
    </div>)
}

}
