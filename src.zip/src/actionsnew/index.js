const CounterTypes = {
    INCREASE_COUNT: 'INCREASE_COUNT',
    DECREASE_COUNT: 'DECREASE_COUNT'
    }
    export default {
    ...CounterTypes,
    }