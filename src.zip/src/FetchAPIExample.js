import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const FetchAPIExample =()=>
{
        const[tdata,setTdata]=useState([])
      //  this.state = {tdata:[]}
    
    useEffect(() => {
        fetch("http://localhost:3001/posts")
        .then(response => response.json())
        .then(data => setTdata(data))
      },[]);

   
        return(<div>
         <table border='1'>
          <tr><th colSpan='6'><Link to="/postapi" >INSERT RECORD CLICK HERE</Link></th></tr>
            <tr><th>UserId</th><th>Name</th><th>Email</th><th>Address</th><th>Edit</th><th>Delete</th></tr>
            {tdata.map((person,i)=>   
             <tr key={i}>
                <td>{person.id}</td>
                <td>{person.name}</td>
                <td>{person.email}</td>
                <td>{person.adderss}</td>
                <td><Link to="/putapi" >Edit</Link></td>

                 <td><Link to="/deleteapi">Delete</Link></td>  
               
            </tr>) }
         </table>
        </div>)
    
}

export default FetchAPIExample;