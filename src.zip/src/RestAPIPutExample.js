import React, { useEffect, useState } from "react";
import { useLocation } from "react-router";
const RestAPIPutExample =()=>
{
    
    let data = useLocation().state;
       // this.state = {tid:'',tname:'',temail:'',taddress:'',tdata:''}
        const[tid,setTid]=useState(data.id)
        const[tname,setTname]=useState(data.name)
        const[temail,setTemail]=useState(data.email)
        const[taddress,setTaddress]=useState(data.adderss)
        const[tdata,setTdata]=useState('')
       
        const [post, setPost] = React.useState(null);
      //  console.log("id is "+data.state);
       
       
      /*  useEffect(() => {
            fetch("http://localhost:3001/posts/"+data.state)
            .then(response => response.json())
            .then(data => {setPost(data);console.log(post);} )
          },[]);*/
    
    const enterData=(e)=>{
       
        if(e.target.id=='tid')
        {
           setTid(e.target.value);
        }
        else if(e.target.id=='tname')
        {
            setTname(e.target.value);
        }
        else if(e.target.id=='temail')
        {
           setTemail(e.target.value);
        }
        else
        {
            setTaddress(e.target.value);
        }
    }
   var submitdata=()=>{
        fetch('http://127.0.0.1:3001/posts/'+tid,{
            method: 'PUT',
            body: JSON.stringify({
             name:tname,
             email:temail,
             adderss:taddress
         }),
            headers:{"content-type":"application/json; charset=UTF-8"}  
             }).then(res => res.json())
   
       .then((data) => {
         window.location.href='/fetchapi';
         console.log('update success');
       //   this.setState({tdata:'update success'})
   
       }).catch(console.log)
       window.location.href='/fetchapi';
    }
  

    return(<div>
         <h1>Update RECORD EXAMPLE</h1>
        <input type="text" onChange={enterData}  placeholder="Enter id" id="tid" value={tid} /> <br/>
        <input type="text" onChange={enterData}  placeholder="Enter name" id="tname" value={tname}  /> <br/>
        <input type="text" onChange={enterData}  placeholder="Enter email" id="temail" value={temail} /> <br/>
        <input type="text" onChange={enterData}  placeholder="Enter address" id="taddress" value={taddress}  /> <br/>
        <br/>
        <input type="button" value="Update" onClick={submitdata} />
        <h1>{tdata}</h1>
    </div>)
}
export default RestAPIPutExample;