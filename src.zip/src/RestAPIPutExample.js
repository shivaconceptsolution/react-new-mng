import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router";
import axios from 'axios'
const RestAPIPutExample =()=>
{
    
        let data = useLocation().state;
      
        const[post, setPost] = React.useState('');
        const tid = useRef();
        const tname = useRef();
        const temail = useRef();
        const tadd = useRef();
    
       
    /* useEffect(() => {
            fetch("http://localhost:3001/posts/"+data)
            .then(response => response.json())
            .then(data => {setPost(data);console.log(post);} )
          },[]);*/

     useEffect(() => {

        axios.get("http://localhost:3001/posts/"+data).then((response) => {
    
          setPost(response.data);
    
        });
    
      }, [])
  
   var submitdata= (e)=>{
    
    e.preventDefault();
   
 /*   fetch('http://127.0.0.1:3001/posts/'+data,{
            method: 'PUT',
            body: JSON.stringify({
             name:tname.current.value,
             email:temail.current.value,
             adderss:tadd.current.value
         }),
            headers:{"content-type":"application/json; charset=UTF-8"}  
             }).then(res => res.json())
   
       .then((data) => {
       
   
       
       }).catch(console.log('error'))
       window.location.href='/fetchapi';*/
       axios.put('http://127.0.0.1:3001/posts/'+data, {
       name:tname.current.value,
       email:temail.current.value,
       adderss:tadd.current.value }).then((response) => {
   
        // setPost(response.data);
   
       
   
       }); 
   
       window.location.href='/fetchapi';
    }
  

    return(<div>
         <h1>Update RECORD EXAMPLE</h1>
        <input type="text" ref={tid}  placeholder="Enter id" id="tid" defaultValue={post.id} /> <br/>
        <input type="text" ref={tname}  placeholder="Enter name" id="tname" defaultValue={post.name}  /> <br/>
        <input type="text" ref={temail}  placeholder="Enter email" id="temail" defaultValue={post.email} /> <br/>
        <input type="text" ref={tadd}  placeholder="Enter address" id="taddress" defaultValue={post.adderss}  /> <br/>
        <br/>
        <input type="button" value="Update" onClick={submitdata} />
        
    </div>)
}
export default RestAPIPutExample;