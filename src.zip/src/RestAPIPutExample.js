import React, { useEffect, useState } from "react";
import { useLocation } from "react-router";
const RestAPIPutExample =()=>
{
    
       
       // this.state = {tid:'',tname:'',temail:'',taddress:'',tdata:''}
        const[tid,setTid]=useState('')
        const[tname,setTname]=useState('')
        const[temail,setTemail]=useState('')
        const[taddress,setTaddress]=useState('')
        const[tdata,setTdata]=useState('')
        let data = useLocation();
        const [post, setPost] = React.useState(null);
        console.log("id is "+data.state);
       
        const baseURL = "http://localhost:3001/posts/"+data.state;
        useEffect(() => {
            fetch(baseURL)
            .then(response => response.json())
            .then(data => setPost(data))
          },[]);
    
    const enterData=(e)=>{
       
        if(e.target.id=='tid')
        {
           setTid(e.target.value);
        }
        else if(e.target.id=='tname')
        {
            setTname(e.target.value);
        }
        else if(e.target.id=='temail')
        {
           setTemail(e.target.value);
        }
        else
        {
            setTaddress(e.target.value);
        }
    }
   var submitdata=()=>{
        fetch('http://127.0.0.1:3001/posts/'+tid,{
            method: 'PUT',
            body: JSON.stringify({
             name:tname,
             email:temail,
             adderss:taddress
         }),
            headers:{"content-type":"application/json; charset=UTF-8"}  
             }).then(res => res.json())
   
       .then((data) => {
   
          console.log(data)
          this.setState({tdata:'update success'})
   
       }).catch(console.log)
    }
  

    return(<div>
         <h1>Update RECORD EXAMPLE</h1>
        <input type="text" onChange={enterData}  placeholder="Enter id" id="tid" value={post.id} /> <br/>
        <input type="text" onChange={enterData}  placeholder="Enter name" id="tname" value={post.tname} /> <br/>
        <input type="text" onChange={enterData}  placeholder="Enter email" id="temail" value={post.temail} /> <br/>
        <input type="text" onChange={enterData}  placeholder="Enter address" id="taddress" value={post.taddress} /> <br/>
        <br/>
        <input type="button" value="Update" onClick={submitdata} />
        <h1>{tdata}</h1>
    </div>)
}
export default RestAPIPutExample;