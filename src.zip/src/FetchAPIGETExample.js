import React from "react";
import { Link } from "react-router-dom";
import axios from 'axios'
export default class FetchAPIGETExample extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {tdata:[]}
    }
    componentDidMount() {

      /*  fetch('http://127.0.0.1:3001/posts')

        .then(res => res.json())

        .then((data) => {

          this.setState({ tdata: data })

         // console.log(this.state.tdata)

        })

        .catch(console.log)*/
        axios.get('http://127.0.0.1:5000/studata').then((repos) => {
    
        this.setState({ tdata: repos.data})
  
        console.log(this.state.tdata)
      });
      }
    render(){
        return(<div>
         <table border='1'>
         <tr><th colSpan='6'><Link to="/postapi" >INSERT RECORD CLICK HERE</Link></th></tr>
            <tr><th>RNO</th><th>Name</th></tr>
            {this.state.tdata.map((person,i)=>   
             <tr key={i}>
                <td>{person.rno}</td>
                <td>{person.name}</td>
               
                <td><Link to="/putapi" state={person.rno}>Edit</Link></td>

                 <td><Link to="/deleteapi" state={person.rno}>Delete</Link></td>  
            </tr>)}   
         </table>
        </div>)
    }
}