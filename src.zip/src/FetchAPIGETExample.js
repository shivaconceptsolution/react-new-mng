import React from "react";
import { Link } from "react-router-dom";

export default class FetchAPIGETExample extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {tdata:[]}
    }
    componentDidMount() {

        fetch('http://127.0.0.1:3001/posts')

        .then(res => res.json())

        .then((data) => {

          this.setState({ tdata: data })

         // console.log(this.state.tdata)

        })

        .catch(console.log)

      }
    render(){
        return(<div>
         <table border='1'>
         <tr><th colSpan='6'><Link to="/postapi" >INSERT RECORD CLICK HERE</Link></th></tr>
            <tr><th>UserId</th><th>Name</th><th>Email</th><th>Address</th><th>Edit</th><th>Delete</th></tr>
            {this.state.tdata.map((person,i)=>   
             <tr key={i}>
                <td>{person.id}</td>
                <td>{person.name}</td>
                <td>{person.email}</td>
                <td>{person.adderss}</td>
                <td><Link to="/putapi" state={person}>Edit</Link></td>

                 <td><Link to="/deleteapi">Delete</Link></td>  
            </tr>)}   
         </table>
        </div>)
    }
}