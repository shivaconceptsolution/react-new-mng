import React, { useRef } from "react";
const UncontrolledComponent=()=>
{
   
        const num1 = useRef(undefined)
        const num2 = useRef(undefined)
    
    const fun=(e)=>
    {
           alert(parseInt(num1.current.value)+
           parseInt(num2.current.value));
           e.preventDefault();
    }
     return(<div>

    <input type="text" ref={num1}  placeholder="Enter first number" />
     <br/>
    <input type="text" ref={num2}  placeholder="Enter second number" />
    <br/>
    <input type="submit" name="btnsubmit" onClick={fun} value="Click" />
    </div>)
    

}

export default UncontrolledComponent;