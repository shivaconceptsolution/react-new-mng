function Sub()
{
    var a=1000;
    var b=200;
    return(<div style={{backgroundColor:'yellow',height:200}}>
        <h2>Result is {a-b}</h2>
    </div>)
}
export default Sub;