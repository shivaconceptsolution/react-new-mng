import React from "react"
import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
export class Layout extends React.Component
{
    
    render(){
        return(
          <div className="container-xxl bg-white p-0">
             <Header/>
              <section>
              <Outlet />     
              </section>
              <Footer/>
             
          </div>

        );

    }

}